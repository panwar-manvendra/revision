function validateorder()
{
     var barbie=document.getElementById("p1").value;
	 var calci=document.getElementById("p2").value;
	 var mob=document.getElementById("p3").value;
	 var lg=document.getElementById("p4").value;
	 
	 if(barbie== ''&&calci== ''&&mob== ''&&lg== '')
	 {
	    alert("no item selcted");
	 }
      
      else
       {
	       anotherWindow=window.open("","newwindow","toolbar,status,resizable");
		   var newContent ="<html><head><title>invoice</title></head>"
		   newContent +="<body><h3>INVOICE</h3>"
		   newContent +="<table border=1><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th></tr>"
		   if(barbie != '')
		   {
		       newContent +="<tr><td>Barbiedoll</td><td>"+barbie+"</td><td>20</td><td>"+(barbie*20)+"</td></tr>"
		   }
		   if(calci != '')
		   {
		         newContent +="<tr><td>Calculator</td><td>"+calci+"</td><td>30</td><td>"+(calci*30)+"</td></tr>"
		   }
		   if(mob != '')
		   {
		       newContent +="<tr><td>MobilePhone</td><td>"+mob+"</td><td>40</td><td>"+(mob*40)+"</td></tr>"
		   }
		   if(lg != '')
		   {
		        newContent +="<tr><td>LG DVD</td><td>"+lg+"</td><td>50</td><td>"+(lg*50)+"</td></tr>"
		   }
		   newContent +="</table>"
		   newContent +="</body></html>"
		   anotherWindow.document.write(newContent);
	   }	  
		
	 
}