function display()
{
    var i=0;
   do
   {      
        if(i%10==0)
	    {
	        document.write("<br>");
	    }
        document.write(i+" ");     
	i++;
   }while(i<=99);
	return("");
}