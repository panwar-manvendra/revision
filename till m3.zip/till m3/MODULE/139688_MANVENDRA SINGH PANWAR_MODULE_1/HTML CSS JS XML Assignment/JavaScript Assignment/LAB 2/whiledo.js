function display()
{
    var i=0;
	    while(i<=99)
        {		
          if(i%10==0)
	      {
	          document.write("<br>");
	      }
          document.write(i+" ");     
	      i++;
	   }
	   return("");
}