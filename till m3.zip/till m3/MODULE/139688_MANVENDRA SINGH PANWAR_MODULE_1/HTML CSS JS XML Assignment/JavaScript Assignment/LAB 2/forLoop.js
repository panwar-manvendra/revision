function display()
{
     var i;
	 for(i=0;i<100;i++)
	 {
          if(i%10==0)
           {
			 document.write("<br>");
		   }
         document.write(i+" ");
	 }
         return("");	 
}