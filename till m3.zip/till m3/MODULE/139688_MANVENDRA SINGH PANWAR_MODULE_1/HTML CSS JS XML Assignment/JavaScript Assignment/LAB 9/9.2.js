function Qualification()
{
	var glevel=window.document.frm.Glevel.value;
	var flag;
	if(glevel == 1)
	{
		
		window.document.frm.qualification.options[0].text="B.E";
		window.document.frm.qualification.options[0].value="B.E";
		
		window.document.frm.qualification.options[1].text="B.Sc";
		window.document.frm.qualification.options[1].value="B.Sc";
		
		window.document.frm.qualification.options[2].text="B.C.A";
		window.document.frm.qualification.options[2].value="B.C.A";
	}
	
	if(glevel==2)
	{
	
		window.document.frm.qualification.options[0].text="M.E";
		window.document.frm.qualification.options[0].value="M.E";
		
		window.document.frm.qualification.options[1].text="M.Sc";
		window.document.frm.qualification.options[1].value="M.Sc";
		
		window.document.frm.qualification.options[2].text="M.C.A";
		window.document.frm.qualification.options[2].value="M.C.A";
	}
	
function validate()
{
	var name=window.document.frm.Name.value;
	var namePattern=/[^a-zA-Z]+$/;
	
	if(name.match(namePattern))
	{
		var nameErrorMsg=document.getElementById("nameErrorId");
		nameErrorMsg.innerHTML="name should have only char";
		return false;
	}
	
	if(name.length<3||name.length>10)
	{
		alert("char should be btwn 3 and 10");
	}
	
	var dob=window.document.frm.dob.value;
	
	if(dob.length==0)
	{
		var dobErrorMsg=document.getElementById("dobErrorId");
		dobErrorMsg.innerHTML="Enter the date in the pattern dd/mm/yyyy";
		return false;
	}
	
	var phone=window.document.frm.phone.value;
	var phonePattern=/\d{3}-\d{4}-\d{4}/;
	
	if(!phone.match(phonePattern))
	{
		var phoneErrorMsg=document.getElementById("phoneErrorId");
		phoneErrorMsg.innerHTML="Phone no should in the format ddd-dddd-dddd";
		return false;
	}
	
	var mail=window.document.frm.mail.value;
	var mailPattern=/[A-Za-z]+[@][a-z]+[.][a-z]/;
	
	if(!mailPattern.test(mail))
	{
		var mailErrorMsg=document.getElementById("emailErrorId");
		mailErrorMsg.innerHTML="invalid email";
		return false;
	}
}
function preview()
{
	var name=window.document.frm.Name.value;
	var dob=window.document.frm.dob.value;
	var phone=window.document.frm.phone.value;
	var mail=window.document.frm.mail.value;
	var glevel=window.document.frm.Glevel.value;
	var qualData=window.document.frm.qualification.value;
	
	var dobyear=window.document.frm.dob.value;
	var yearPattern=/\d{4}/;
	var re=RegExp(yearPattern);
	var year=re.exec(dobyear);
	
	var todaydate=new Date();
	var thisYear=todaydate.getFullYear();
	var age=eval(thisYear)-eval(year);
	var newWin=window.open("","newWin","width=400","height=400");
	newWin.document.write("<html><body bgcolor='green'><title>Preview page</title>");
	newWin.document.write("name:"+name+"<br/>Date of birth:"+dob+"<br/>phone number:"+phone+"<br/>Email"+mail);
	newWin.document.write("</body></html>");
}	