function Test()
{
	var reg=window.document.form1.txt1.value;
	var regularexp=new RegExp(reg);
	var str=window.document.form1.txt2.value;
	
	if(str.match(regularexp))
	{
		alert("successfull match");
	}
	else
	{
		alert("Please Enter valid data");
	}
}


function Match()
{
	var reg=window.document.form1.txt1.value;
	var regularexp=new RegExp(reg);
	var str=window.document.form1.txt2.value;
	var x=regularexp.exec(str);
	var y=str.indexOf(x);
	
	{
		alert("match at position "+y+":"+x);
	}
	
}
