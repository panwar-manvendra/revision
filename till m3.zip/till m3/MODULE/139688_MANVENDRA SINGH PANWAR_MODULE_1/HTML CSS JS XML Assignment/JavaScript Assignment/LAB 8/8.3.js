function mail_ck()
{
	var sub=window.document.form8.txt1.value;
	var cc=window.document.form8.txt2.value;
	var bcc=window.document.form8.txt3.value;
	var re = new RegExp("[a-z]@[a-z].[a-z]+");
	if(!(cc.match(re)) || !(bcc.match(re)))
	{

		alert("Enter valid cc/BCC");
		
	}
	else
		window.location.href="mailto:mailid?subject="+sub+"cc"+cc+"bcc"+bcc;
	
	
	
}

