   function validrepay(repaym)
	   {    
	        var numbers=/^[0-9]+$/;
			if(repaym == '')
			{
				alert("repayment should not be empty");
			}
	       else if(repaym <=7 && repaym >=15)
	       {
	         window.alert("repayment sholud be between 7yrs and 15yrs");
	       }
	       else if(!repaym.match(numbers))
	       {
	           window.alert("only numbers");
	       }
	   }
	   function validloan(loan)
	   {
		   var numbers=/^[0-9]+$/
		   if(loan == '')
		   {
			   alert("loan field is empty");
		   }
	       else if(loan >1500000)
	       {
		       alert("loan amount sholud not be greater than 15 lakhs");
	       }
	      else if(!loan.match(numbers))
	      {
		       alert("plse enter valid loan value");
	      }
	  }
	  function validrate(rof)
	  {
		  var numbers=/^[0-9]+$/
		  if(rof == '')
		  {
			  alert("rate of interest is empty");
		  }
		  else if(rof >10)
		  {
			  alert("rateofinterest should be lessthan  10");
		  }
		  else if(!rof.match(numbers))
		  {
			  alert("rate of interest is not valid one");
		  }
	  }
function validate()
{
       var loan=document.getElementById("a1").value;
	   var rof=document.getElementById("a2").value;
	   var repaym=document.getElementById("a3").value;
	  
	    var months = 12*repaym;
	    var monpay = loan*(rof/100);
	    var totpay = monpay * 12 * repaym;
	    var totint = (loan*rof*repaym)/100;
		alert(months+' '+ monpay+' '+totpay);
		if(loan == '' && rof == '' && repaym == '')
	    {
		document.getElementById("monpay").value=0;
		document.getElementById("totpay").value=0;
		document.getElementById("totint").value=0;
	    }
	   
		document.getElementById("monpay").value = monpay;
		document.getElementById("totpay").value = totpay;
		document.getElementById("totint").value = totint;
	   
}
