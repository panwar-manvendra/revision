function product_details()
{
	var data=window.document.frm1.Category_Type.value;
	
	if(data=="Electronics")
	{
		window.document.frm1.Product_Type.options[0].text="Television";
		window.document.frm1.Product_Type.options[0].value="Television";
		
		window.document.frm1.Product_Type.options[1].text="Laptop";
		window.document.frm1.Product_Type.options[1].value="Laptop";
		
		window.document.frm1.Product_Type.options[2].text="Phone";
		window.document.frm1.Product_Type.options[2].value="Phone";
	}
	
		if(data=="Grocery")
	{
		window.document.frm1.Product_Type.options[0].text="Soap";
		window.document.frm1.Product_Type.options[0].value="Soap";
		
		window.document.frm1.Product_Type.options[1].text="Powder";
		window.document.frm1.Product_Type.options[1].value="Powder";
		
	}
}
function total_price()
{
	var quantity=window.document.frm1.txt1.value;
	var product_type=window.document.frm1.Product_Type.value;
	var quantPattern=/[0-9]*/;
	
	if((!quantPattern.test(quantity)))
	{
		alert("Enter valid details");
	}
	if(product_type=="Television")
	{
		var price=20000;
		var totalprice=(price*quantity);
		window.document.frm1.txt2.value=totalprice;
	}
	if(product_type=="Laptop")
	{
		var price=30000;
		var totalprice=(price*quantity);
		window.document.frm1.txt2.value=totalprice;
	}
	if(product_type=="Phone")
	{
		var price=10000;
		var totalprice=(price*quantity);
		window.document.frm1.txt2.value=totalprice;
	}
	if(product_type=="Soap")
	{
		var price=40;
		var totalprice=(price*quantity);
		window.document.frm1.txt2.value=totalprice;
	}
	if(product_type=="Powder")
	{
		var price=90;
		var totalprice=(price*quantity);
		window.document.frm1.txt2.value=totalprice;
	}
	
}