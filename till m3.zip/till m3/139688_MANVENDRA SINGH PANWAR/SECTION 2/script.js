function validate(form)
{
	// for validate course name
	ErrorText= "";
	if ( ( form.courseName[0].checked == false ) && ( form.courseName[1].checked == false ) ) 
	{
	alert ( "Please select the course name" ); 
	return false;	
	}
	if (ErrorText= "") 
	{ 
      form.submit() 
	}
   
    // for validate guide name
    var options = document.getElementById("guideName").options;
    var result = false;

    for (var i = 0; i < options.length; i++) 
	{
        if(document.getElementById("gname").value == options[i].value) 
		{
        result = true;
      ``}
    }
    if (result == false) 
	{ 
		alert ( "Please select Guide Name from Guide Name Dropdown" ); 
	} 	
	
	// for submit all values
	var form=document.forms.myForm;
	var course=form.courseName.value;
	alert("Your "+course+" Registration Details are added successfully. All the best for your Research Work!!!");
}